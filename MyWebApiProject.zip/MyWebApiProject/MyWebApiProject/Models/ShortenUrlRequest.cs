﻿namespace UrlShortenerApi.Models
{
    public class ShortenUrlRequest
    {
        public string OriginalUrl { get; set; }
        public string CustomShortUrl { get; set; } 

        public string NewCustomShortUrl { get; set; }
    }
}

