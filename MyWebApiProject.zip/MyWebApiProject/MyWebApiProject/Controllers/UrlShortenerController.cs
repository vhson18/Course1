﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using UrlShortenerApi.Models;
using UrlShortenerApi.Services;

namespace UrlShortenerApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UrlShortenerController : ControllerBase
    {
        private readonly UrlShortenerService _service;

        public UrlShortenerController(UrlShortenerService service)
        {
            _service = service;
        }


        [HttpPost("shorten")]
        public async Task<IActionResult> ShortenUrl([FromBody] ShortenUrlRequest request)
        {
            // If no customShortUrl is provided, a random one will be generated
            var shortUrl = await _service.ShortenUrlAsync(request.OriginalUrl, request.CustomShortUrl);
            return Ok(new { shortUrl });
        }



        [HttpGet("{shortUrl}")]
        public async Task<IActionResult> RedirectToOriginalUrl(string shortUrl)
        {
            var originalUrl = await _service.GetOriginalUrlAsync(shortUrl);
            if (string.IsNullOrEmpty(originalUrl))
            {
                // Log the issue
                Console.WriteLine($"Original URL not found for short URL: {shortUrl}");
                return NotFound();
            }

            // Validate the original URL
            if (!Uri.TryCreate(originalUrl, UriKind.Absolute, out _))
            {
                // Log the issue
                Console.WriteLine($"Invalid original URL: {originalUrl}");
                return BadRequest("Invalid original URL");
            }

            // Log the successful redirect
            Console.WriteLine($"Redirecting short URL: {shortUrl} to original URL: {originalUrl}");
            return RedirectPermanent(originalUrl);
        }

        [HttpDelete("{shortUrl}")]
        public async Task<IActionResult> DeleteShortUrl(string shortUrl)
        {
            var deleted = await _service.DeleteShortUrlAsync(shortUrl);

            if (!deleted)
            {
                return NotFound();
            }

            return NoContent();
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateShortUrl([FromBody] ShortenUrlRequest request)
        {
            if (string.IsNullOrEmpty(request.NewCustomShortUrl))
            {
                return BadRequest("New short URL must be provided.");
            }

            var success = await _service.UpdateShortUrlAsync(request.CustomShortUrl, request.NewCustomShortUrl);

            if (!success)
            {
                return NotFound("The original short URL was not found.");
            }

            return Ok(new { message = "Short URL updated successfully." });
        }

    }
}
