﻿using MongoDB.Driver;
using System;
using System.Threading.Tasks;
using UrlShortenerApi.Data;
using UrlShortenerApi.Models;

namespace UrlShortenerApi.Services
{
    public class UrlShortenerService
    {
        private readonly UrlShortenerContext _context;

        public UrlShortenerService(UrlShortenerContext context)
        {
            _context = context;
        }

        public async Task<string> ShortenUrlAsync(string originalUrl, string customShortUrl = null)
        {
            string shortUrl;

            // Check if a custom short URL is provided
            if (string.IsNullOrEmpty(customShortUrl))
            {
                // Generate a random string for the short URL
                shortUrl = GenerateRandomUrlPart(6);
            }
            else
            {
                // Use the custom short URL provided by the user
                shortUrl = customShortUrl;
            }

            // Check if the generated or custom short URL already exists
            var existingMapping = await GetOriginalUrlAsync(shortUrl);
            if (existingMapping != null)
            {
                throw new InvalidOperationException("Short URL already exists.");
            }

            var urlMapping = new UrlMapping
            {
                ShortUrl = shortUrl,
                OriginalUrl = originalUrl
            };

            await _context.UrlMappings.InsertOneAsync(urlMapping);

            return shortUrl;
        }


        public async Task<string> GetOriginalUrlAsync(string shortUrl)
        {
            var filter = Builders<UrlMapping>.Filter.Eq("ShortUrl", shortUrl);
            var urlMapping = await _context.UrlMappings.Find(filter).FirstOrDefaultAsync();

            return urlMapping?.OriginalUrl;
        }

        public async Task<bool> UpdateShortUrlAsync(string oldShortUrl, string newShortUrl)
        {
            var filter = Builders<UrlMapping>.Filter.Eq("ShortUrl", oldShortUrl);
            var update = Builders<UrlMapping>.Update.Set("ShortUrl", newShortUrl);

            var result = await _context.UrlMappings.UpdateOneAsync(filter, update);

            return result.ModifiedCount > 0;
        }


        public async Task<bool> DeleteShortUrlAsync(string shortUrl)
        {
            var filter = Builders<UrlMapping>.Filter.Eq("ShortUrl", shortUrl);
            var result = await _context.UrlMappings.DeleteOneAsync(filter);

            return result.DeletedCount > 0;
        }
        private string GenerateRandomUrlPart(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            var result = new char[length];

            for (int i = 0; i < length; i++)
            {
                result[i] = chars[random.Next(chars.Length)];
            }

            return new string(result);
        }

    }
}
